const tintColorLight = '#0a7ea4';
const tintColorDark = '#fff';

export const Colors = {
    light: {
        text: '#11181C',
        background: '#fff',
        tint: tintColorLight,
        icon: '#687076',
        tabIconDefault: '#687076',
        tabIconSelected: tintColorLight,
        card: '#f9f9f9',
        border: '#f0f0f0',
        subtext: '#666',
        primary: '#0a7ea4',
        error: '#ff4444',
    },
    dark: {
        text: '#ECEDEE',
        background: '#151718',
        tint: tintColorDark,
        icon: '#9BA1A6',
        tabIconDefault: '#9BA1A6',
        tabIconSelected: tintColorDark,
        card: '#1e1e1e',
        border: '#333',
        subtext: '#999',
        primary: '#0a7ea4',
        error: '#ff6666',
    },
};
